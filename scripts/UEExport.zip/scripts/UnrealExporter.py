# -*- coding: utf-8 -*-
"""
unreal_exporter.py  -  Maya -> Unreal Engine FBX exporter

Run from the Script Editor (Python tab) by pasting the whole file, or put it in
your scripts folder and run:

    import unreal_exporter
    unreal_exporter.show()

Main features
    * Static Mesh / Skeletal Mesh / Animation export presets
    * "Snap to origin for export": the selection is moved to the world origin
      only while the FBX is written, then put back exactly where it was
    * One file per selected object, or everything in one file
    * Auto-includes Unreal collision meshes (UCX_/UBX_/USP_/UCP_ + mesh name)
    * Auto-includes the skeleton of selected skinned meshes
    * Baked animation export with a frame range, skeleton-only option
    * Unreal naming prefixes (SM_, SK_, A_)
    * Validate button for the usual import problems
"""
from __future__ import print_function

import json
import os
import re

import maya.cmds as cmds
import maya.mel as mel

WINDOW = 'ueExporterWindow'
OPTION_VAR = 'ueExporterSettings'

STATIC, SKELETAL, ANIM = 'Static Mesh', 'Skeletal Mesh', 'Animation'
TYPES = [STATIC, SKELETAL, ANIM]
PREFIXES = {STATIC: 'SM_', SKELETAL: 'SK_', ANIM: 'A_'}
COLLISION_PREFIXES = ('UCX_', 'UBX_', 'USP_', 'UCP_')

PIVOT, BB_BOTTOM, BB_CENTER = ('Object pivot', 'Bounding box bottom center',
                               'Bounding box center')
PIVOT_MODES = [PIVOT, BB_BOTTOM, BB_CENTER]
FBX_VERSIONS = ['FBX202000', 'FBX201900', 'FBX201800', 'FBX201600', 'FBX201400']
UP_AXES = ['Scene default', 'Y', 'Z']

GAP = 4                 # spacing between options, buttons and log
BUTTON_HEIGHT = 34
MIN_LOG_HEIGHT = 110

T_PLUGS = ['translate', 'translateX', 'translateY', 'translateZ']
R_PLUGS = ['rotate', 'rotateX', 'rotateY', 'rotateZ']

DEFAULTS = {
    'path': '', 'type': STATIC, 'prefix': 'SM_', 'name': '', 'per_object': True,
    'snap': True, 'pivot': PIVOT, 'zero_rot': False,
    'smoothing': True, 'tangents': False, 'triangulate': False,
    'smooth_mesh': False, 'collision': True, 'shapes': True,
    'skeleton': True, 'skel_only': True,
    'version': FBX_VERSIONS[0], 'up': UP_AXES[0], 'ascii': False, 'embed': False,
}


# --------------------------------------------------------------------------
# Scene helpers
# --------------------------------------------------------------------------
def short_name(node):
    """Leaf name without DAG path or namespace."""
    return node.split('|')[-1].split(':')[-1]


def unique(nodes):
    seen, out = set(), []
    for n in nodes:
        if n not in seen:
            seen.add(n)
            out.append(n)
    return out


def top_level(nodes):
    """Drop nodes whose ancestor is also in the list (avoids double moves)."""
    nodes = unique(nodes)
    return [n for n in nodes
            if not any(n != o and n.startswith(o + '|') for o in nodes)]


def meshes_under(nodes):
    if not nodes:
        return []
    shapes = cmds.listRelatives(nodes, allDescendents=True, type='mesh',
                                fullPath=True) or []
    return [s for s in shapes if not cmds.getAttr(s + '.intermediateObject')]


def root_joints(nodes):
    """Top joints of every skeleton that is selected, under the selection,
    or skinned to a mesh in the selection."""
    if not nodes:
        return []
    joints = [n for n in nodes if cmds.nodeType(n) == 'joint']
    joints += cmds.listRelatives(nodes, allDescendents=True, type='joint',
                                 fullPath=True) or []
    for mesh in meshes_under(nodes):
        history = cmds.listHistory(mesh) or []
        clusters = cmds.ls(history, type='skinCluster') if history else []
        for cluster in clusters:
            influences = cmds.skinCluster(cluster, q=True, influence=True) or []
            if influences:
                joints += cmds.ls(influences, long=True, type='joint')
    roots = []
    for joint in unique(joints):
        parts = joint.split('|')[1:]
        for i in range(len(parts)):
            path = '|' + '|'.join(parts[:i + 1])
            if cmds.nodeType(path) == 'joint':
                roots.append(path)
                break
    return unique(roots)


def collision_for(node):
    """Unreal collision meshes named after this node, e.g. UCX_SM_Crate_01."""
    name = short_name(node)
    patterns = []
    for prefix in COLLISION_PREFIXES:
        patterns += [prefix + name, prefix + name + '_*']
    found = cmds.ls(*patterns, long=True, type='transform') or []
    return [f for f in found if f != node]


def reference_point(mode, pivot_node, bbox_nodes):
    """World-space point that should land on the origin."""
    if mode == PIVOT:
        return cmds.xform(pivot_node, q=True, worldSpace=True, rotatePivot=True)
    bb = cmds.exactWorldBoundingBox(bbox_nodes)
    point = [(bb[0] + bb[3]) / 2.0, (bb[1] + bb[4]) / 2.0, (bb[2] + bb[5]) / 2.0]
    if mode == BB_BOTTOM:
        up = 1 if cmds.upAxis(q=True, axis=True) == 'y' else 2
        point[up] = bb[up]
    return point


# --------------------------------------------------------------------------
# Temporary origin snap
# --------------------------------------------------------------------------
def snap_to_origin(movers, mode, pivot_node, bbox_nodes, zero_rot, log):
    """Move `movers` so the reference point sits on the world origin.

    Returns a state dict for restore_snap(). If any mover cannot be moved
    (animated / constrained / un-unlockable channels) nothing is moved, so
    the relative layout of the export is never broken.
    """
    state = {'values': [], 'relock': [], 'moved': False}
    plugs = T_PLUGS + (R_PLUGS if zero_rot else [])

    for node in movers:
        driven = [p for p in plugs
                  if cmds.listConnections(node + '.' + p, source=True,
                                          destination=False)]
        if driven:
            log('  ! Origin snap skipped: {0} has keyed/constrained channels '
                '({1}).'.format(short_name(node), ', '.join(driven)))
            return state

    try:
        for node in movers:
            for plug in plugs:
                attr = node + '.' + plug
                if cmds.getAttr(attr, lock=True):
                    cmds.setAttr(attr, lock=False)
                    state['relock'].append(attr)
    except RuntimeError:
        log('  ! Origin snap skipped: could not unlock transform channels.')
        return state

    for node in movers:
        state['values'].append((node,
                                cmds.getAttr(node + '.translate')[0],
                                cmds.getAttr(node + '.rotate')[0]))

    if zero_rot:
        for node in movers:
            cmds.xform(node, worldSpace=True, rotation=(0, 0, 0))

    point = reference_point(mode, pivot_node, bbox_nodes)
    for node in movers:
        cmds.move(-point[0], -point[1], -point[2], node,
                  relative=True, worldSpace=True)
    state['moved'] = True
    return state


def restore_snap(state):
    """Put everything back exactly: original channel values and locks."""
    for node, translate, rotate in state['values']:
        try:
            cmds.setAttr(node + '.translate', *translate)
            cmds.setAttr(node + '.rotate', *rotate)
        except RuntimeError as exc:
            cmds.warning('Could not restore {0}: {1}'.format(node, exc))
    for attr in state['relock']:
        try:
            cmds.setAttr(attr, lock=True)
        except RuntimeError:
            pass


# --------------------------------------------------------------------------
# FBX
# --------------------------------------------------------------------------
def ensure_fbx_plugin():
    if not cmds.pluginInfo('fbxmaya', q=True, loaded=True):
        cmds.loadPlugin('fbxmaya', quiet=True)


def mel_bool(value):
    return 'true' if value else 'false'


def fbx_export_selection(path, s, start, end):
    """Write the current selection to `path` using settings dict `s`."""
    animated = s['type'] == ANIM
    commands = [
        'FBXResetExport',
        'FBXExportSmoothingGroups -v ' + mel_bool(s['smoothing']),
        'FBXExportTangents -v ' + mel_bool(s['tangents']),
        'FBXExportTriangulate -v ' + mel_bool(s['triangulate']),
        'FBXExportSmoothMesh -v ' + mel_bool(s['smooth_mesh']),
        'FBXExportHardEdges -v false',
        'FBXExportInstances -v false',
        'FBXExportReferencedAssetsContent -v true',
        'FBXExportSkins -v true',
        'FBXExportShapes -v ' + mel_bool(s['shapes']),
        'FBXExportSkeletonDefinitions -v true',
        'FBXExportInputConnections -v false',
        'FBXExportConstraints -v false',
        'FBXExportCameras -v false',
        'FBXExportLights -v false',
        'FBXExportEmbeddedTextures -v ' + mel_bool(s['embed']),
        'FBXExportAnimationOnly -v false',
        'FBXExportBakeComplexAnimation -v ' + mel_bool(animated),
        'FBXExportConvertUnitString cm',
        'FBXExportScaleFactor 1.0',
        'FBXExportInAscii -v ' + mel_bool(s['ascii']),
        'FBXExportFileVersion -v ' + s['version'],
        'FBXExportGenerateLog -v false',
    ]
    if animated:
        commands += [
            'FBXExportBakeComplexStart -v {0}'.format(int(start)),
            'FBXExportBakeComplexEnd -v {0}'.format(int(end)),
            'FBXExportBakeComplexStep -v 1',
            'FBXExportBakeResampleAnimation -v true',
        ]
    if s['up'] in ('Y', 'Z'):
        commands.append('FBXExportUpAxis ' + s['up'].lower())
    for command in commands:
        mel.eval(command)

    # Keep stray keys out of mesh files; not available in very old plugins.
    try:
        mel.eval('FBXProperty "Export|IncludeGrp|Animation" -v {0}'
                 .format(1 if animated else 0))
    except RuntimeError:
        pass

    safe_path = path.replace('\\', '/').replace('"', '\\"')
    mel.eval('FBXExport -f "{0}" -s'.format(safe_path))


# --------------------------------------------------------------------------
# Validation
# --------------------------------------------------------------------------
def validate(nodes, export_type):
    """Return a list of human-readable issues for the given transforms."""
    issues = []
    unit = cmds.currentUnit(q=True, linear=True)
    if unit != 'cm':
        issues.append('Scene units are "{0}". Unreal works in cm; the FBX is '
                      'converted on export, but check the scale in engine.'
                      .format(unit))
    for node in nodes:
        name = short_name(node)
        if len(cmds.ls(node.split('|')[-1])) > 1:
            issues.append('{0}: name is not unique in the scene.'.format(name))
        if cmds.nodeType(node) == 'joint':
            continue
        scale = cmds.getAttr(node + '.scale')[0]
        if any(v < 0 for v in scale):
            issues.append('{0}: negative scale (flipped normals in Unreal).'
                          .format(name))
        elif any(abs(v - 1.0) > 1e-4 for v in scale):
            issues.append('{0}: scale is not frozen {1}.'.format(
                name, tuple(round(v, 3) for v in scale)))

    for mesh in meshes_under(nodes):
        name = short_name(cmds.listRelatives(mesh, parent=True,
                                             fullPath=True)[0])
        if not cmds.polyEvaluate(mesh, uvcoord=True):
            issues.append('{0}: no UVs.'.format(name))
        elif export_type == STATIC and \
                len(cmds.polyUVSet(mesh, q=True, allUVSets=True) or []) < 2:
            issues.append('{0}: single UV set (Unreal will need to generate '
                          'lightmap UVs).'.format(name))
        history = cmds.listHistory(mesh, pruneDagObjects=True) or []
        skinned = bool(cmds.ls(history, type='skinCluster')) if history else False
        if export_type == STATIC and skinned:
            issues.append('{0}: is skinned but export type is Static Mesh.'
                          .format(name))
        elif export_type == STATIC and history:
            issues.append('{0}: has construction history.'.format(name))
        elif export_type != STATIC and not skinned:
            issues.append('{0}: is not skinned.'.format(name))

    if export_type != STATIC:
        roots = root_joints(nodes)
        if not roots:
            issues.append('No skeleton found for the selection.')
        elif len(roots) > 1:
            issues.append('Multiple root joints ({0}). Unreal needs one root '
                          'per skeleton.'.format(
                              ', '.join(short_name(r) for r in roots)))
    return issues


# --------------------------------------------------------------------------
# UI
# --------------------------------------------------------------------------
class UnrealExporter(object):

    def __init__(self):
        self.widgets = {}       # key -> (kind, control)
        self.settings = dict(DEFAULTS)
        if cmds.optionVar(exists=OPTION_VAR):
            try:
                self.settings.update(json.loads(cmds.optionVar(q=OPTION_VAR)))
            except (ValueError, TypeError):
                pass
        if not self.settings['path']:
            self.settings['path'] = os.path.join(
                cmds.workspace(q=True, rootDirectory=True),
                'UnrealExport').replace('\\', '/')
        self.build()

    # ---- widget helpers ---------------------------------------------------
    def _check(self, key, label, annotation='', command=None):
        ctrl = cmds.checkBox(label=label, value=bool(self.settings[key]),
                             annotation=annotation)
        if command:
            cmds.checkBox(ctrl, e=True, changeCommand=command)
        self.widgets[key] = ('check', ctrl)
        return ctrl

    def _menu(self, key, label, items, command=None):
        ctrl = cmds.optionMenuGrp(label=label, columnWidth=(1, 110),
                                  adjustableColumn=2)
        for item in items:
            cmds.menuItem(label=item)
        if self.settings[key] in items:
            cmds.optionMenuGrp(ctrl, e=True, value=self.settings[key])
        if command:
            cmds.optionMenuGrp(ctrl, e=True, changeCommand=command)
        self.widgets[key] = ('menu', ctrl)
        return ctrl

    def _text(self, key, label, placeholder=''):
        ctrl = cmds.textFieldGrp(label=label, text=self.settings[key],
                                 columnWidth=(1, 110), adjustableColumn=2,
                                 placeholderText=placeholder)
        self.widgets[key] = ('text', ctrl)
        return ctrl

    def read(self):
        s = {}
        for key, (kind, ctrl) in self.widgets.items():
            if kind == 'check':
                s[key] = cmds.checkBox(ctrl, q=True, value=True)
            elif kind == 'menu':
                s[key] = cmds.optionMenuGrp(ctrl, q=True, value=True)
            elif kind == 'text':
                s[key] = cmds.textFieldGrp(ctrl, q=True, text=True).strip()
            elif kind == 'path':
                s[key] = cmds.textFieldButtonGrp(ctrl, q=True, text=True).strip()
        cmds.optionVar(stringValue=(OPTION_VAR, json.dumps(s)))
        return s

    def log(self, message):
        cmds.scrollField(self.log_field, e=True, insertionPosition=0,
                         insertText=message + '\n')
        print(message)

    # ---- layout -----------------------------------------------------------
    def build(self):
        if cmds.window(WINDOW, exists=True):
            cmds.deleteUI(WINDOW)
        cmds.window(WINDOW, title='Unreal Exporter', widthHeight=(430, 760),
                    sizeable=True)
        # Layout: scroll > form > [options column | buttons | log].
        # The log is pinned to the bottom of the form, so it stretches when
        # the window gets taller. fit_height() never lets the form get
        # shorter than its content, so a small window scrolls instead.
        self.scroll = cmds.scrollLayout(
            childResizable=True, resizeCommand=lambda *_: self.fit_height())
        self.form = cmds.formLayout()
        self.options = cmds.columnLayout(adjustableColumn=True, rowSpacing=4)

        def refit(*_):
            cmds.evalDeferred(self.fit_height)

        def frame(label):
            cmds.frameLayout(label=label, collapsable=True, marginWidth=8,
                             marginHeight=6, collapseCommand=refit,
                             expandCommand=refit)
            cmds.columnLayout(adjustableColumn=True, rowSpacing=4)

        def end_frame():
            cmds.setParent('..')
            cmds.setParent('..')

        frame('Output')
        path = cmds.textFieldButtonGrp(
            label='Export folder', text=self.settings['path'],
            buttonLabel='Browse', columnWidth=(1, 110), adjustableColumn=2,
            buttonCommand=lambda *_: self.browse())
        self.widgets['path'] = ('path', path)
        self._menu('type', 'Export type', TYPES,
                   command=lambda *_: self.on_type_changed())
        self._text('prefix', 'Name prefix')
        self._text('name', 'File name', placeholder='blank = use object name')
        self._check('per_object', 'One file per selected object (static meshes)',
                    'Off: everything selected goes into a single FBX.')
        end_frame()

        frame('Origin Snap')
        self._check('snap', 'Snap to world origin for export, then restore',
                    'Moves the selection to 0,0,0 only while the FBX is '
                    'written. Nothing is left moved in the scene.',
                    command=lambda *_: self.refresh_enabled())
        self._menu('pivot', 'Snap point', PIVOT_MODES)
        self._check('zero_rot', 'Also zero world rotation (static, per object)',
                    'Exports the object unrotated. Skipped when the object '
                    'has separate collision meshes.')
        end_frame()

        frame('Geometry')
        self._check('smoothing', 'Smoothing groups')
        self._check('tangents', 'Tangents and binormals')
        self._check('triangulate', 'Triangulate')
        self._check('smooth_mesh', 'Smooth mesh preview')
        self._check('shapes', 'Blend shapes (morph targets)')
        self._check('collision', 'Include collision meshes (UCX_/UBX_/USP_/UCP_)',
                    'Finds e.g. UCX_<meshName>_01 anywhere in the scene and '
                    'exports it with the mesh.')
        end_frame()

        frame('Skeleton and Animation')
        self._check('skeleton', 'Auto-include skeleton of skinned meshes')
        self._check('skel_only', 'Animation: export skeleton only (no meshes)')
        self.range_field = cmds.intFieldGrp(
            label='Frame range', numberOfFields=2, columnWidth=(1, 110),
            value1=int(cmds.playbackOptions(q=True, minTime=True)),
            value2=int(cmds.playbackOptions(q=True, maxTime=True)))
        self.range_button = cmds.button(label='Use Time Slider Range',
                                        command=lambda *_: self.range_from_timeline())
        end_frame()

        frame('FBX')
        self._menu('version', 'FBX version', FBX_VERSIONS)
        self._menu('up', 'Up axis', UP_AXES)
        self._check('ascii', 'ASCII file')
        self._check('embed', 'Embed media')
        end_frame()

        cmds.setParent(self.form)
        buttons = cmds.rowLayout(numberOfColumns=2, adjustableColumn=2,
                                 columnWidth=(1, 120))
        cmds.button(label='Validate', height=BUTTON_HEIGHT, width=120,
                    command=lambda *_: self.run_validate())
        cmds.button(label='Export Selection', height=BUTTON_HEIGHT,
                    backgroundColor=(0.25, 0.5, 0.35),
                    command=lambda *_: self.run_export())
        cmds.setParent('..')

        self.log_field = cmds.scrollField(editable=False, wordWrap=False)
        cmds.formLayout(self.form, e=True, attachForm=[
            (self.options, 'top', 0), (self.options, 'left', 0),
            (self.options, 'right', 0),
            (buttons, 'left', 0), (buttons, 'right', 0),
            (self.log_field, 'left', 0), (self.log_field, 'right', 0),
            (self.log_field, 'bottom', 0)],
            attachControl=[(buttons, 'top', GAP, self.options),
                           (self.log_field, 'top', GAP, buttons)])
        self.refresh_enabled()
        cmds.showWindow(WINDOW)
        cmds.evalDeferred(self.fit_height)

    def fit_height(self):
        """Stretch the content to the window height, but never below the
        height the controls need (then the scroll bar takes over)."""
        if not cmds.window(WINDOW, exists=True) or \
                not cmds.scrollLayout(self.scroll, exists=True):
            return
        needed = (cmds.columnLayout(self.options, q=True, height=True) +
                  BUTTON_HEIGHT + MIN_LOG_HEIGHT + GAP * 2)
        available = cmds.scrollLayout(self.scroll, q=True, height=True) - 4
        cmds.formLayout(self.form, e=True, height=max(needed, available))

    # ---- callbacks --------------------------------------------------------
    def browse(self):
        ctrl = self.widgets['path'][1]
        start = cmds.textFieldButtonGrp(ctrl, q=True, text=True)
        result = cmds.fileDialog2(fileMode=3, caption='Export folder',
                                  startingDirectory=start)
        if result:
            cmds.textFieldButtonGrp(ctrl, e=True, text=result[0])

    def on_type_changed(self):
        export_type = cmds.optionMenuGrp(self.widgets['type'][1], q=True,
                                         value=True)
        prefix_ctrl = self.widgets['prefix'][1]
        current = cmds.textFieldGrp(prefix_ctrl, q=True, text=True)
        if current in list(PREFIXES.values()) + ['']:
            cmds.textFieldGrp(prefix_ctrl, e=True, text=PREFIXES[export_type])
        self.refresh_enabled()

    def refresh_enabled(self):
        export_type = cmds.optionMenuGrp(self.widgets['type'][1], q=True,
                                         value=True)
        static, anim = export_type == STATIC, export_type == ANIM
        snap = cmds.checkBox(self.widgets['snap'][1], q=True, value=True)
        cmds.checkBox(self.widgets['per_object'][1], e=True, enable=static)
        cmds.checkBox(self.widgets['collision'][1], e=True, enable=static)
        cmds.checkBox(self.widgets['snap'][1], e=True, enable=not anim)
        cmds.optionMenuGrp(self.widgets['pivot'][1], e=True,
                           enable=snap and not anim)
        cmds.checkBox(self.widgets['zero_rot'][1], e=True,
                      enable=snap and static)
        cmds.checkBox(self.widgets['skeleton'][1], e=True, enable=not static)
        cmds.checkBox(self.widgets['skel_only'][1], e=True, enable=anim)
        cmds.intFieldGrp(self.range_field, e=True, enable=anim)
        cmds.button(self.range_button, e=True, enable=anim)

    def range_from_timeline(self):
        cmds.intFieldGrp(self.range_field, e=True,
                         value1=int(cmds.playbackOptions(q=True, minTime=True)),
                         value2=int(cmds.playbackOptions(q=True, maxTime=True)))

    def run_validate(self):
        s = self.read()
        selection = cmds.ls(selection=True, long=True, type='transform')
        if not selection:
            self.log('Validate: nothing selected.')
            return
        issues = validate(selection, s['type'])
        self.log('Validate ({0}): {1} issue(s)'.format(s['type'], len(issues)))
        for issue in issues:
            self.log('  - ' + issue)

    # ---- export -----------------------------------------------------------
    def build_jobs(self, s, selection):
        """Each job: name, nodes to export, nodes to move, snap references."""
        jobs = []
        tops = top_level(selection)

        if s['type'] == STATIC:
            groups = [[t] for t in tops] if s['per_object'] else [tops]
            for group in groups:
                nodes = list(group)
                if s['collision']:
                    for node in group:
                        nodes += collision_for(node)
                nodes = unique(nodes)
                single = len(group) == 1 and (s['per_object'] or not s['name'])
                jobs.append({
                    'name': short_name(group[0]) if s['per_object']
                            else (s['name'] or short_name(group[0])),
                    'nodes': nodes, 'movers': top_level(nodes),
                    'pivot_node': group[0], 'bbox_nodes': group,
                    'single': single})
            if s['per_object'] and s['name'] and len(jobs) == 1:
                jobs[0]['name'] = s['name']
            return jobs

        roots = root_joints(selection) if s['skeleton'] or s['type'] == ANIM else []
        name = s['name'] or short_name(tops[0])
        if s['type'] == SKELETAL:
            jobs.append({
                'name': name, 'nodes': unique(selection + roots),
                # Only the root joints move: moving skinned meshes as well
                # would double-transform them.
                'movers': top_level(roots),
                'pivot_node': roots[0] if roots else tops[0],
                'bbox_nodes': tops, 'single': False})
        else:
            nodes = roots if (s['skel_only'] and roots) else unique(selection + roots)
            jobs.append({'name': name, 'nodes': nodes, 'movers': [],
                         'pivot_node': None, 'bbox_nodes': [], 'single': False})
        return jobs

    def run_export(self):
        s = self.read()
        selection = cmds.ls(selection=True, long=True, type='transform')
        if not selection:
            cmds.warning('Unreal Exporter: select at least one object.')
            self.log('Nothing selected.')
            return
        if not s['path']:
            cmds.warning('Unreal Exporter: set an export folder.')
            return
        if not os.path.isdir(s['path']):
            os.makedirs(s['path'])
        ensure_fbx_plugin()

        start = cmds.intFieldGrp(self.range_field, q=True, value1=True)
        end = cmds.intFieldGrp(self.range_field, q=True, value2=True)
        original_selection = cmds.ls(selection=True, long=True)
        jobs = self.build_jobs(s, selection)
        exported = 0

        self.log('--- Export: {0} ---'.format(s['type']))
        for job in jobs:
            file_name = re.sub(r'[^A-Za-z0-9_\-]', '_', job['name'])
            if s['prefix'] and not file_name.startswith(s['prefix']):
                file_name = s['prefix'] + file_name
            path = os.path.join(s['path'], file_name + '.fbx').replace('\\', '/')

            state = None
            cmds.undoInfo(stateWithoutFlush=False)   # keep the undo queue clean
            try:
                if s['snap'] and s['type'] != ANIM:
                    if not job['movers']:
                        self.log('  ! Origin snap skipped: no root joint found.')
                    else:
                        zero_rot = (s['zero_rot'] and s['type'] == STATIC and
                                    job['single'] and len(job['movers']) == 1)
                        if s['zero_rot'] and s['type'] == STATIC and not zero_rot:
                            self.log('  ! Rotation not zeroed for {0} (more than '
                                     'one node moves).'.format(job['name']))
                        state = snap_to_origin(
                            job['movers'], s['pivot'], job['pivot_node'],
                            job['bbox_nodes'], zero_rot, self.log)
                cmds.select(job['nodes'], replace=True)
                fbx_export_selection(path, s, start, end)
                exported += 1
                self.log('  {0}{1}'.format(
                    path, '  (snapped to origin)' if state and state['moved'] else ''))
            except Exception as exc:    # report and carry on with other files
                self.log('  ! FAILED {0}: {1}'.format(file_name, exc))
            finally:
                if state:
                    restore_snap(state)
                cmds.undoInfo(stateWithoutFlush=True)

        if original_selection:
            cmds.select(original_selection, replace=True)
        else:
            cmds.select(clear=True)
        self.log('Done: {0} of {1} file(s) written.'.format(exported, len(jobs)))


def show():
    return UnrealExporter()


if __name__ == '__main__':
    show()