"""Blender's Build modifier timing rule. No Maya imports, so it can be tested anywhere."""


def visible_face_count(frame, start, length, total):
    """Return how many of `total` faces are shown at `frame`.

    None are shown up to `start`, all of them from `start + length` onward, and
    faces appear one after another at an even rate in between.
    """
    length = max(float(length), 1.0)
    elapsed = min(max(float(frame) - float(start), 0.0), length)
    # Multiply before dividing so whole frames land exactly:
    # 100 * (29 / 100) is 28.999... in floating point, 100 * 29 / 100 is 29.
    return int(total * elapsed / length)
