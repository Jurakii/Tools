"""Saved Build defaults, stored as Maya optionVars so they survive restarts."""
from maya import cmds

START_FRAME = "buildModifier_startFrame"
LENGTH = "buildModifier_length"
DEFAULTS = {START_FRAME: 1.0, LENGTH: 100.0}
MIN_LENGTH = 1.0


def get(name):
    if cmds.optionVar(exists=name):
        return float(cmds.optionVar(query=name))
    return DEFAULTS[name]


def save(name, value):
    value = float(value)
    if name == LENGTH:
        value = max(value, MIN_LENGTH)
    cmds.optionVar(floatValue=(name, value))


def reset():
    for name, value in DEFAULTS.items():
        save(name, value)
