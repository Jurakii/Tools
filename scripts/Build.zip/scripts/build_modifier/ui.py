"""Build Options: the window behind a double-click on the shelf button."""
from maya import cmds

from build_modifier import core, options

WINDOW = "buildModifierOptions"
START_FIELD = "buildModifierOptionsStartFrame"
LENGTH_FIELD = "buildModifierOptionsLength"


def show_options():
    """Open Build Options, or bring the open one forward with the saved values."""
    if cmds.window(WINDOW, exists=True):
        _load_fields()
        cmds.showWindow(WINDOW)
        return WINDOW

    cmds.window(WINDOW, title="Build Options", menuBar=True, widthHeight=(500, 170))
    cmds.menu(label="Edit")
    cmds.menuItem(label="Save Settings", command=lambda *_: _save_fields())
    cmds.menuItem(label="Reset Settings", command=lambda *_: _reset())

    form = cmds.formLayout()
    body = cmds.columnLayout(adjustableColumn=True)
    cmds.frameLayout(label="Settings", collapsable=True, marginWidth=10, marginHeight=8)
    cmds.columnLayout(adjustableColumn=True, rowSpacing=4)
    slider = dict(field=True, precision=3, columnWidth3=(100, 80, 200), columnAlign3=("right", "left", "left"),
                  adjustableColumn=3, changeCommand=lambda *_: _save_fields())
    cmds.floatSliderGrp(START_FIELD, label="Start Frame", minValue=1, maxValue=1000,
                        fieldMinValue=-100000, fieldMaxValue=100000, **slider)
    cmds.floatSliderGrp(LENGTH_FIELD, label="Length", minValue=options.MIN_LENGTH, maxValue=1000,
                        fieldMinValue=options.MIN_LENGTH, fieldMaxValue=100000, **slider)

    cmds.setParent(form)
    build = cmds.button(label="Build", command=lambda *_: _apply(close=True))
    apply_ = cmds.button(label="Apply", command=lambda *_: _apply(close=False))
    close = cmds.button(label="Close", command=lambda *_: cmds.deleteUI(WINDOW))
    cmds.formLayout(
        form, edit=True,
        attachForm=[(body, "top", 0), (body, "left", 0), (body, "right", 0),
                    (build, "left", 5), (build, "bottom", 5), (apply_, "bottom", 5),
                    (close, "bottom", 5), (close, "right", 5)],
        attachControl=[(body, "bottom", 5, build)],
        attachPosition=[(build, "right", 2, 33), (apply_, "left", 2, 33), (apply_, "right", 2, 67),
                        (close, "left", 2, 67)],
        attachNone=[(build, "top"), (apply_, "top"), (close, "top")])

    _load_fields()
    cmds.showWindow(WINDOW)
    return WINDOW


def _load_fields():
    cmds.floatSliderGrp(START_FIELD, edit=True, value=options.get(options.START_FRAME))
    cmds.floatSliderGrp(LENGTH_FIELD, edit=True, value=options.get(options.LENGTH))


def _save_fields():
    options.save(options.START_FRAME, cmds.floatSliderGrp(START_FIELD, query=True, value=True))
    options.save(options.LENGTH, cmds.floatSliderGrp(LENGTH_FIELD, query=True, value=True))


def _reset():
    options.reset()
    _load_fields()


def _apply(close):
    _save_fields()
    core.apply_build()
    if close:
        cmds.deleteUI(WINDOW)
