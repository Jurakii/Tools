"""Shelf button for Build: click applies it to the selection, double-click opens Build Options."""
import os
import time

from maya import cmds, mel

from build_modifier import core, ui

LABEL = "Build"
ICON = "buildModifier.png"
CLICK_COMMAND = "import build_modifier.shelf\nbuild_modifier.shelf.on_click()"
DOUBLE_CLICK_COMMAND = "import build_modifier.shelf\nbuild_modifier.shelf.on_double_click()"

# Maya may run the click command for the first click of a double-click. on_click remembers
# when it last built something so on_double_click can undo that before opening the options.
_last_build_click = None


def on_click():
    global _last_build_click
    nodes = core.apply_build()
    _last_build_click = time.monotonic() if nodes else None


def on_double_click():
    global _last_build_click
    clicked_at, _last_build_click = _last_build_click, None
    if (clicked_at is not None
            and time.monotonic() - clicked_at <= _double_click_seconds() + 0.1
            and cmds.undoInfo(query=True, undoName=True) == "Build"):
        cmds.undo()
    ui.show_options()


def install(shelf=None):
    """Add the Build button to `shelf` (default: the active shelf) unless it's already there."""
    top = mel.eval("$_buildModifierShelfTop = $gShelfTopLevel")
    shelf = shelf or "%s|%s" % (top, cmds.tabLayout(top, query=True, selectTab=True))
    for button in cmds.shelfLayout(shelf, query=True, childArray=True) or []:
        button = "%s|%s" % (shelf, button)
        if (cmds.objectTypeUI(button) == "shelfButton"
                and "build_modifier" in (cmds.shelfButton(button, query=True, command=True) or "")):
            return button
    button = cmds.shelfButton(
        parent=shelf,
        label=LABEL,
        imageOverlayLabel=LABEL,
        image=_icon(),
        annotation="Build: click to apply to the selected meshes, double-click for options",
        sourceType="python",
        command=CLICK_COMMAND,
        doubleClickCommand=DOUBLE_CLICK_COMMAND,
    )
    mel.eval('saveAllShelves "%s"' % top)
    return button


def _icon():
    path = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "icons", ICON))
    return path.replace("\\", "/") if os.path.exists(path) else "pythonFamily.png"


def _double_click_seconds():
    try:
        from PySide6.QtWidgets import QApplication
    except ImportError:
        try:
            from PySide2.QtWidgets import QApplication
        except ImportError:
            return 0.5
    app = QApplication.instance()
    return app.doubleClickInterval() / 1000.0 if app else 0.5
