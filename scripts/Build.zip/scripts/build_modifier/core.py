"""Add and remove the Build modifier on polygon meshes."""
import contextlib
import os

import maya.api.OpenMaya as om
from maya import cmds

from build_modifier import options

PLUGIN = "buildModifierNode"
NODE_TYPE = "buildModifier"

DIVIDER_ATTR = "buildDivider"
START_ATTR = "buildStartFrame"
LENGTH_ATTR = "buildLength"
ORIG_TAG_ATTR = "buildModifierOrig"  # marks Orig shapes made here, so remove_build can fold them back


def apply_build(start=None, length=None, targets=None):
    """Add Build to each mesh in `targets` (default: the selection), or update the Build it already has.

    Start Frame and Length come from the saved defaults unless given.
    Returns the Build nodes that were added or updated.
    """
    start = options.get(options.START_FRAME) if start is None else float(start)
    length = options.get(options.LENGTH) if length is None else float(length)
    length = max(length, options.MIN_LENGTH)
    selection = cmds.ls(selection=True, long=True) or []
    shapes = _mesh_shapes(selection if targets is None else targets)
    if not shapes:
        cmds.warning("Build: select one or more polygon meshes.")
        return []

    ensure_plugin()
    nodes = []
    with _undo_chunk("Build"):
        for shape in shapes:
            node = find_build_node(shape) or _insert_build_node(shape)
            xform = _transform_of(shape)
            _add_transform_attrs(xform, start, length)
            _set_unless_driven(xform + "." + START_ATTR, start)
            _set_unless_driven(xform + "." + LENGTH_ATTR, length)
            _connect_once(xform + "." + START_ATTR, node + ".startFrame")
            _connect_once(xform + "." + LENGTH_ATTR, node + ".length")
            nodes.append(node)
        _restore_selection(selection)
    om.MGlobal.displayInfo("Build: %s (Start Frame %g, Length %g)."
                           % (", ".join(_short(_transform_of(s)) for s in shapes), start, length))
    return nodes


def remove_build(targets=None):
    """Take Build off each mesh in `targets` (default: the selection), leaving the whole mesh.

    Returns the transforms Build was removed from.
    """
    selection = cmds.ls(selection=True, long=True) or []
    shapes = [s for s in _mesh_shapes(selection if targets is None else targets) if find_build_node(s)]
    if not shapes:
        cmds.warning("Build: none of the selected meshes have Build.")
        return []

    removed = []
    with _undo_chunk("Remove Build"):
        for shape in shapes:
            node = find_build_node(shape)
            upstream = _source_plug(node + ".inMesh")
            # Reconnect before deleting: Maya deletes history nodes left with no outgoing connection.
            if upstream:
                cmds.connectAttr(upstream, shape + ".inMesh", force=True)
            cmds.delete(node)
            if upstream:
                source = upstream.split(".")[0]
                if cmds.attributeQuery(ORIG_TAG_ATTR, node=source, exists=True):
                    # The mesh had no history before Build: bake the geometry back and drop the Orig.
                    cmds.dgeval(shape + ".outMesh")
                    cmds.disconnectAttr(upstream, shape + ".inMesh")
                    cmds.delete(source)
            xform = _transform_of(shape)
            if not any(find_build_node(s) for s in _mesh_shapes([xform])):
                _remove_transform_attrs(xform)
            removed.append(xform)
        _restore_selection(selection)
    om.MGlobal.displayInfo("Build removed from %s." % ", ".join(_short(x) for x in removed))
    return removed


def find_build_node(shape):
    """The Build node feeding `shape` directly, or None."""
    sources = cmds.listConnections(shape + ".inMesh", source=True, destination=False) or []
    if sources and cmds.nodeType(sources[0]) == NODE_TYPE:
        return sources[0]
    return None


def ensure_plugin():
    if cmds.pluginInfo(PLUGIN, query=True, loaded=True):
        return
    try:
        cmds.loadPlugin(PLUGIN + ".py", quiet=True)
    except RuntimeError:
        # Not on MAYA_PLUG_IN_PATH: use the plug-ins folder that ships beside scripts/.
        here = os.path.dirname(os.path.abspath(__file__))
        cmds.loadPlugin(os.path.normpath(os.path.join(here, "..", "..", "plug-ins", PLUGIN + ".py")), quiet=True)


def _mesh_shapes(nodes):
    """Visible mesh shapes for the given transforms, shapes or components. Warns about anything else."""
    if not nodes:
        return []
    shapes, skipped = [], []
    for node in cmds.ls(nodes, objectsOnly=True, long=True) or []:
        if cmds.objectType(node, isAType="mesh"):
            found = [] if cmds.getAttr(node + ".intermediateObject") else [node]
        elif cmds.objectType(node, isAType="transform"):
            found = cmds.listRelatives(node, shapes=True, type="mesh", noIntermediate=True, fullPath=True) or []
        else:
            found = []
        if not found:
            skipped.append(node)
        for shape in found:
            if shape not in shapes:
                shapes.append(shape)
    if skipped:
        cmds.warning("Build: skipped %s (not a polygon mesh)." % ", ".join(_short(n) for n in skipped))
    return shapes


def _insert_build_node(shape):
    upstream = _source_plug(shape + ".inMesh")
    if upstream:
        source_plug = _move_tweaks_upstream(shape, upstream)
    else:
        source_plug = _make_orig_shape(shape) + ".outMesh"
    node = cmds.createNode(NODE_TYPE, skipSelect=True)
    cmds.connectAttr(_time_node() + ".outTime", node + ".time")
    cmds.connectAttr(source_plug, node + ".inMesh")
    cmds.connectAttr(node + ".outMesh", shape + ".inMesh", force=True)
    return node


def _move_tweaks_upstream(shape, upstream_plug):
    """Move vertex tweaks stored on `shape` into a polyTweak fed by `upstream_plug`.

    Tweaks on the shape are applied after Build by vertex number, and Build renumbers
    vertices, so they have to sit upstream. Returns the plug Build should read from.
    """
    tweaks = _shape_tweaks(shape)
    if not tweaks:
        return upstream_plug
    tweak_node = cmds.createNode("polyTweak", skipSelect=True)
    cmds.connectAttr(upstream_plug, tweak_node + ".inputPolymesh")
    for index, offset in tweaks.items():
        cmds.setAttr("%s.tweak[%d]" % (tweak_node, index), *offset)
        cmds.setAttr("%s.pnts[%d]" % (shape, index), 0.0, 0.0, 0.0)
    return tweak_node + ".output"


def _make_orig_shape(shape):
    """Hidden copy of a history-free mesh for Build to read from, like a deformer's Orig shape."""
    orig = cmds.createNode("mesh", name=_short(shape) + "Orig", parent=_transform_of(shape), skipSelect=True)
    orig = cmds.ls(orig, long=True)[0]
    # Copying through outMesh bakes in the shape's vertex tweaks, so they're cleared on the shape after.
    cmds.connectAttr(shape + ".outMesh", orig + ".inMesh")
    cmds.dgeval(orig + ".outMesh")
    cmds.disconnectAttr(shape + ".outMesh", orig + ".inMesh")
    cmds.setAttr(orig + ".intermediateObject", True)
    cmds.addAttr(orig, longName=ORIG_TAG_ATTR, attributeType="bool", defaultValue=True)
    for index in _shape_tweaks(shape):
        cmds.setAttr("%s.pnts[%d]" % (shape, index), 0.0, 0.0, 0.0)
    return orig


def _shape_tweaks(shape):
    """{vertex index: (x, y, z)} for every non-zero tweak stored on the shape."""
    plug = om.MFnDependencyNode(om.MSelectionList().add(shape).getDependNode(0)).findPlug("pnts", False)
    tweaks = {}
    for index in plug.getExistingArrayAttributeIndices():
        element = plug.elementByLogicalIndex(index)
        offset = tuple(element.child(axis).asFloat() for axis in range(3))
        if any(offset):
            tweaks[index] = offset
    return tweaks


def _add_transform_attrs(xform, start, length):
    if not cmds.attributeQuery(DIVIDER_ATTR, node=xform, exists=True):
        cmds.addAttr(xform, longName=DIVIDER_ATTR, niceName="Build", attributeType="enum", enumName="--------")
        cmds.setAttr(xform + "." + DIVIDER_ATTR, channelBox=True)
        cmds.setAttr(xform + "." + DIVIDER_ATTR, lock=True)
    if not cmds.attributeQuery(START_ATTR, node=xform, exists=True):
        cmds.addAttr(xform, longName=START_ATTR, niceName="Start Frame", attributeType="double",
                     defaultValue=start, keyable=True)
    if not cmds.attributeQuery(LENGTH_ATTR, node=xform, exists=True):
        cmds.addAttr(xform, longName=LENGTH_ATTR, niceName="Length", attributeType="double",
                     minValue=options.MIN_LENGTH, defaultValue=length, keyable=True)


def _remove_transform_attrs(xform):
    for attr in (START_ATTR, LENGTH_ATTR, DIVIDER_ATTR):
        if cmds.attributeQuery(attr, node=xform, exists=True):
            cmds.setAttr(xform + "." + attr, lock=False)
            cmds.deleteAttr(xform + "." + attr)


def _set_unless_driven(plug, value):
    if cmds.listConnections(plug, source=True, destination=False) or cmds.getAttr(plug, lock=True):
        cmds.warning("Build: %s is keyed, connected or locked, so it was left as it is." % _short(plug))
        return
    cmds.setAttr(plug, value)


def _connect_once(source, destination):
    if not cmds.isConnected(source, destination):
        cmds.connectAttr(source, destination, force=True)


def _source_plug(plug):
    sources = cmds.listConnections(plug, source=True, destination=False, plugs=True, fullNodeName=True) or []
    return sources[0] if sources else None


def _transform_of(shape):
    return cmds.listRelatives(shape, parent=True, fullPath=True)[0]


def _time_node():
    return (cmds.ls(type="time") or ["time1"])[0]


def _short(name):
    return name.split("|")[-1]


def _restore_selection(selection):
    existing = cmds.ls(selection, long=True) if selection else []
    if existing:
        cmds.select(existing, replace=True)
    else:
        cmds.select(clear=True)


@contextlib.contextmanager
def _undo_chunk(name):
    cmds.undoInfo(openChunk=True, chunkName=name)
    try:
        yield
    finally:
        cmds.undoInfo(closeChunk=True)
