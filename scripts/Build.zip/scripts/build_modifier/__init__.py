"""Blender's Build modifier for Maya.

    import build_modifier
    build_modifier.apply_build()    # selected meshes, saved Start Frame and Length
    build_modifier.show_options()   # change the saved Start Frame and Length
    build_modifier.remove_build()   # take Build off the selected meshes
"""
from build_modifier.core import apply_build, remove_build
from build_modifier.ui import show_options

__all__ = ["apply_build", "remove_build", "show_options"]
