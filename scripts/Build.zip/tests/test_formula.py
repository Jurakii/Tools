"""Build timing rule. Runs with plain Python, pytest or mayapy; no Maya needed."""
import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "scripts"))

from build_modifier.formula import visible_face_count  # noqa: E402


class VisibleFaceCountTest(unittest.TestCase):
    def test_before_start_shows_nothing(self):
        self.assertEqual(visible_face_count(0, 1, 100, 6), 0)

    def test_at_start_shows_nothing(self):
        self.assertEqual(visible_face_count(1, 1, 100, 6), 0)

    def test_midway_shows_half(self):
        self.assertEqual(visible_face_count(51, 1, 100, 100), 50)

    def test_at_end_shows_everything(self):
        self.assertEqual(visible_face_count(101, 1, 100, 6), 6)

    def test_past_end_shows_everything(self):
        self.assertEqual(visible_face_count(500, 1, 100, 6), 6)

    def test_default_cube_table(self):
        expected = {0: 0, 1: 0, 17: 0, 18: 1, 35: 2, 51: 3, 68: 4, 85: 5, 100: 5, 101: 6, 150: 6}
        for frame, faces in expected.items():
            self.assertEqual(visible_face_count(frame, 1, 100, 6), faces, "frame %d" % frame)

    def test_whole_frames_land_exactly(self):
        # 100 * (29 / 100) is 28.999... in floating point.
        self.assertEqual(visible_face_count(30, 1, 100, 100), 29)

    def test_length_one(self):
        self.assertEqual(visible_face_count(10, 10, 1, 8), 0)
        self.assertEqual(visible_face_count(11, 10, 1, 8), 8)

    def test_length_below_one_counts_as_one(self):
        self.assertEqual(visible_face_count(10.5, 10, 0, 10), 5)

    def test_negative_start_frame(self):
        self.assertEqual(visible_face_count(-50, -100, 100, 10), 5)

    def test_fractional_frames(self):
        self.assertEqual(visible_face_count(1.5, 1, 1, 10), 5)
        self.assertEqual(visible_face_count(2.25, 1, 10, 100), 12)

    def test_empty_mesh(self):
        self.assertEqual(visible_face_count(50, 1, 100, 0), 0)


if __name__ == "__main__":
    unittest.main()
