"""Build inside Maya. Run with mayapy from the build_modifier folder:

    "C:/Program Files/Autodesk/Maya2024/bin/mayapy.exe" -m unittest discover -s tests -v

Under mayapy the tests start Maya standalone with a throwaway preferences folder,
so your own Maya prefs are never touched. Skipped under plain Python.
"""
import os
import shutil
import sys
import tempfile
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "scripts"))

cmds = om = core = options = None
_temp_dirs = []


def setUpModule():
    global cmds, om, core, options
    try:
        import maya.standalone
        from maya import cmds as maya_cmds
    except ImportError:
        raise unittest.SkipTest("Run these tests with mayapy.")
    if not hasattr(maya_cmds, "about"):  # not inside a running Maya yet
        os.environ["MAYA_APP_DIR"] = _temp_dir()
        plugin_path = os.environ.get("MAYA_PLUG_IN_PATH", "")
        os.environ["MAYA_PLUG_IN_PATH"] = os.pathsep.join(p for p in (os.path.join(ROOT, "plug-ins"), plugin_path) if p)
        maya.standalone.initialize(name="python")
    import maya.api.OpenMaya as maya_om
    from build_modifier import core as build_core, options as build_options
    cmds, om, core, options = maya_cmds, maya_om, build_core, build_options


def tearDownModule():
    for path in _temp_dirs:
        shutil.rmtree(path, ignore_errors=True)


def _temp_dir():
    path = tempfile.mkdtemp(prefix="build_modifier_tests_")
    _temp_dirs.append(path)
    return path


class BuildTest(unittest.TestCase):
    def setUp(self):
        cmds.file(new=True, force=True)
        cmds.undoInfo(state=True, infinity=True)
        options.reset()

    # helpers -------------------------------------------------------------

    def shape(self, xform):
        return cmds.listRelatives(xform, shapes=True, noIntermediate=True, fullPath=True)[0]

    def mesh(self, xform):
        return om.MFnMesh(om.MSelectionList().add(self.shape(xform)).getDagPath(0))

    def faces_at(self, xform, frame):
        cmds.currentTime(frame)
        return self.mesh(xform).numPolygons

    def build_nodes(self):
        return cmds.ls(type="buildModifier") or []

    def points(self, xform):
        return [tuple(round(c, 4) for c in p)[:3] for p in self.mesh(xform).getPoints()]

    # behaviour -----------------------------------------------------------

    def test_default_cube_table(self):
        cube = cmds.polyCube()[0]
        core.apply_build(targets=[cube])
        expected = {0: 0, 1: 0, 17: 0, 18: 1, 35: 2, 51: 3, 68: 4, 85: 5, 100: 5, 101: 6, 150: 6}
        for frame, faces in expected.items():
            self.assertEqual(self.faces_at(cube, frame), faces, "frame %d" % frame)

    def test_unused_vertices_are_dropped(self):
        plane = cmds.polyPlane(subdivisionsX=10, subdivisionsY=10)[0]
        core.apply_build(targets=[plane])
        cmds.currentTime(11)  # 10 faces: the first row
        self.assertEqual(self.mesh(plane).numPolygons, 10)
        self.assertEqual(self.mesh(plane).numVertices, 22)

    def test_attributes_on_transform_drive_node(self):
        cube = cmds.polyCube()[0]
        node = core.apply_build(targets=[cube])[0]
        self.assertTrue(cmds.isConnected(cube + ".buildStartFrame", node + ".startFrame"))
        self.assertTrue(cmds.isConnected(cube + ".buildLength", node + ".length"))
        self.assertEqual(cmds.attributeQuery("buildStartFrame", node=cube, niceName=True), "Start Frame")
        self.assertEqual(cmds.attributeQuery("buildLength", node=cube, niceName=True), "Length")
        self.assertTrue(cmds.getAttr(cube + ".buildDivider", lock=True))
        cmds.setAttr(cube + ".buildStartFrame", 11)
        cmds.setAttr(cube + ".buildLength", 10)
        self.assertEqual(self.faces_at(cube, 16), 3)

    def test_uses_saved_defaults(self):
        options.save(options.START_FRAME, 10)
        options.save(options.LENGTH, 20)
        cube = cmds.polyCube()[0]
        core.apply_build(targets=[cube])
        self.assertEqual(cmds.getAttr(cube + ".buildStartFrame"), 10)
        self.assertEqual(cmds.getAttr(cube + ".buildLength"), 20)
        self.assertEqual(self.faces_at(cube, 20), 3)

    def test_history_free_mesh_gets_hidden_orig(self):
        cube = cmds.polyCube()[0]
        cmds.delete(cube, constructionHistory=True)
        before = self.points(cube)
        core.apply_build(targets=[cube])
        shapes = cmds.listRelatives(cube, shapes=True, fullPath=True)
        self.assertEqual(len(shapes), 2)
        self.assertTrue(any(cmds.getAttr(s + ".intermediateObject") for s in shapes))
        self.assertEqual(self.faces_at(cube, 51), 3)
        self.assertEqual(self.faces_at(cube, 101), 6)
        self.assertEqual(self.points(cube), before)

    def test_tweaks_survive_on_history_free_mesh(self):
        cube = cmds.polyCube()[0]
        cmds.delete(cube, constructionHistory=True)
        cmds.move(0, 1, 0, cube + ".vtx[7]", relative=True)
        before = self.points(cube)
        core.apply_build(targets=[cube])
        self.assertEqual(self.faces_at(cube, 101), 6)
        self.assertEqual(self.points(cube), before)  # tweak kept, not applied twice

    def test_tweaks_move_upstream_on_mesh_with_history(self):
        cube = cmds.polyCube()[0]
        cmds.move(0, 1, 0, cube + ".vtx[7]", relative=True)
        before = self.points(cube)
        core.apply_build(targets=[cube])
        self.assertEqual(core._shape_tweaks(self.shape(cube)), {})
        self.assertEqual(len(cmds.ls(type="polyTweak")), 1)
        self.assertEqual(self.faces_at(cube, 101), 6)
        self.assertEqual(self.points(cube), before)
        cmds.currentTime(51)
        self.assertTrue(set(self.points(cube)) <= set(before))  # partial mesh uses the tweaked positions

    def test_skinned_mesh_still_deforms(self):
        cube = cmds.polyCube()[0]
        cmds.select(clear=True)
        joint = cmds.joint()
        cmds.skinCluster(joint, cube)
        core.apply_build(targets=[cube])
        self.assertEqual(self.faces_at(cube, 51), 3)
        cmds.setAttr(joint + ".translateY", 5)
        self.assertTrue(all(abs(p[1] - 5) <= 0.5 for p in self.points(cube)))

    def test_reapply_resets_values_without_stacking(self):
        cube = cmds.polyCube()[0]
        core.apply_build(targets=[cube])
        cmds.setAttr(cube + ".buildLength", 300)
        options.save(options.LENGTH, 20)
        core.apply_build(targets=[cube])
        self.assertEqual(len(self.build_nodes()), 1)
        self.assertEqual(cmds.getAttr(cube + ".buildLength"), 20)

    def test_reapply_leaves_keyed_attribute_alone(self):
        cube = cmds.polyCube()[0]
        core.apply_build(targets=[cube])
        cmds.setKeyframe(cube, attribute="buildLength", time=1, value=50)
        options.save(options.LENGTH, 20)
        core.apply_build(targets=[cube])
        cmds.currentTime(1)
        self.assertEqual(cmds.getAttr(cube + ".buildLength"), 50)

    def test_one_undo_and_one_redo(self):
        cube = cmds.polyCube()[0]
        cmds.flushUndo()
        core.apply_build(targets=[cube])
        self.assertEqual(cmds.undoInfo(query=True, undoName=True), "Build")
        cmds.undo()
        self.assertEqual(self.build_nodes(), [])
        self.assertFalse(cmds.attributeQuery("buildLength", node=cube, exists=True))
        self.assertEqual(cmds.listConnections(self.shape(cube) + ".inMesh"), ["polyCube1"])
        cmds.redo()
        self.assertEqual(len(self.build_nodes()), 1)
        self.assertEqual(self.faces_at(cube, 51), 3)

    def test_selection_skips_non_meshes_and_is_kept(self):
        cube = cmds.polyCube()[0]
        sphere = cmds.polySphere()[0]
        curve = cmds.circle()[0]
        cmds.select(cube, sphere, curve)
        nodes = core.apply_build()
        self.assertEqual(len(nodes), 2)
        self.assertFalse(cmds.attributeQuery("buildLength", node=curve, exists=True))
        self.assertEqual(cmds.ls(selection=True), [cube, sphere, curve])

    def test_component_selection_counts(self):
        cube = cmds.polyCube()[0]
        cmds.select(cube + ".f[2]")
        self.assertEqual(len(core.apply_build()), 1)

    def test_nothing_selected_changes_nothing(self):
        cmds.polyCube()
        cmds.select(clear=True)
        self.assertEqual(core.apply_build(), [])
        self.assertEqual(self.build_nodes(), [])

    def test_has_no_effect_shows_whole_mesh(self):
        cube = cmds.polyCube()[0]
        node = core.apply_build(targets=[cube])[0]
        cmds.setAttr(node + ".nodeState", 1)
        self.assertEqual(self.faces_at(cube, 1), 6)
        cmds.setAttr(node + ".nodeState", 0)
        self.assertEqual(self.faces_at(cube, 1), 0)

    def test_hard_edges_points_and_uvs_match_source(self):
        cylinder = cmds.polyCylinder()[0]
        reference = self.mesh(cmds.polyCylinder()[0])
        core.apply_build(targets=[cylinder])
        cmds.currentTime(97)  # 21 of 22 faces: the sides and the bottom cap
        built = self.mesh(cylinder)
        self.assertEqual(built.numPolygons, 21)

        def corners(fn, face):
            ids = fn.getPolygonVertices(face)
            return ([tuple(round(c, 4) for c in fn.getPoint(v))[:3] for v in ids],
                    [tuple(round(c, 4) for c in fn.getPolygonUV(face, i)) for i in range(len(ids))])

        def edge_hardness(fn):
            # Edges on the open border of a part-built mesh border one face, so hardness can't
            # affect their shading (and Maya reports them as hard); compare interior edges only.
            hardness = {}
            edges = om.MItMeshEdge(fn.dagPath())
            while not edges.isDone():
                if not edges.onBoundary():
                    a, b = (tuple(round(c, 4) for c in fn.getPoint(edges.vertexId(i)))[:3] for i in (0, 1))
                    hardness[frozenset((a, b))] = not edges.isSmooth
                edges.next()
            return hardness

        for face in range(built.numPolygons):
            self.assertEqual(corners(built, face), corners(reference, face))
        reference_hardness = edge_hardness(reference)
        built_hardness = edge_hardness(built)
        self.assertTrue(any(built_hardness.values()) and not all(built_hardness.values()))
        for edge, hard in built_hardness.items():
            self.assertEqual(hard, reference_hardness[edge])

    def test_extra_uv_sets_and_colour_sets_carry_over(self):
        plane = cmds.polyPlane(subdivisionsX=2, subdivisionsY=2)[0]
        cmds.polyUVSet(plane, copy=True, uvSet="map1", newUVSet="lightmap")
        cmds.polyUVSet(plane, currentUVSet=True, uvSet="lightmap")
        cmds.polyEditUV(plane + ".map[0:8]", scaleU=0.5, scaleV=0.5, pivotU=0, pivotV=0)
        cmds.polyUVSet(plane, currentUVSet=True, uvSet="map1")
        cmds.polyColorPerVertex(plane + ".vtx[0]", rgb=(1, 0, 0), colorDisplayOption=True)
        source = self.mesh(plane)

        def corner_uvs(fn, face):
            return {uv_set: [tuple(round(c, 4) for c in fn.getPolygonUV(face, i, uv_set)) for i in range(4)]
                    for uv_set in ("map1", "lightmap")}

        expected = [corner_uvs(source, face) for face in (0, 1)]
        self.assertNotEqual(expected[0]["map1"], expected[0]["lightmap"])

        core.apply_build(targets=[plane], length=4)
        cmds.currentTime(3)
        built = self.mesh(plane)
        self.assertEqual(built.numPolygons, 2)
        self.assertEqual(set(built.getUVSetNames()), {"map1", "lightmap"})
        self.assertEqual([corner_uvs(built, face) for face in (0, 1)], expected)
        colors = built.getFaceVertexColors("colorSet1")
        self.assertEqual(tuple(colors[0]), (1.0, 0.0, 0.0, 1.0))
        self.assertEqual(tuple(colors[1]), (-1.0, -1.0, -1.0, -1.0))

    def test_empty_before_start_frame(self):
        cube = cmds.polyCube()[0]
        core.apply_build(targets=[cube], start=10)
        self.assertEqual(self.faces_at(cube, 5), 0)
        self.assertEqual(self.mesh(cube).numVertices, 0)

    # removing ------------------------------------------------------------

    def test_remove_restores_mesh_with_history(self):
        cube = cmds.polyCube()[0]
        core.apply_build(targets=[cube])
        self.assertEqual(core.remove_build(targets=[cube]), [cmds.ls(cube, long=True)[0]])
        self.assertEqual(self.build_nodes(), [])
        self.assertFalse(cmds.attributeQuery("buildDivider", node=cube, exists=True))
        self.assertEqual(cmds.listConnections(self.shape(cube) + ".inMesh"), ["polyCube1"])
        self.assertEqual(self.faces_at(cube, 1), 6)

    def test_remove_restores_history_free_mesh(self):
        cube = cmds.polyCube()[0]
        cmds.delete(cube, constructionHistory=True)
        cmds.move(0, 1, 0, cube + ".vtx[7]", relative=True)
        before = self.points(cube)
        core.apply_build(targets=[cube])
        cmds.currentTime(1)
        core.remove_build(targets=[cube])
        self.assertEqual(len(cmds.listRelatives(cube, shapes=True)), 1)
        self.assertIsNone(cmds.listConnections(self.shape(cube) + ".inMesh"))
        self.assertEqual(self.mesh(cube).numPolygons, 6)
        self.assertEqual(self.points(cube), before)

    def test_remove_then_apply_again(self):
        cube = cmds.polyCube()[0]
        core.apply_build(targets=[cube])
        core.remove_build(targets=[cube])
        core.apply_build(targets=[cube])
        self.assertEqual(self.faces_at(cube, 51), 3)

    # files ---------------------------------------------------------------

    def test_save_and_reopen(self):
        folder = _temp_dir()
        for kind, extension in (("mayaAscii", ".ma"), ("mayaBinary", ".mb")):
            cmds.file(new=True, force=True)
            cube = cmds.polyCube()[0]
            core.apply_build(targets=[cube])
            path = os.path.join(folder, "build" + extension)
            cmds.file(rename=path)
            cmds.file(save=True, type=kind, force=True)
            cmds.file(path, open=True, force=True)
            self.assertEqual(self.faces_at(cube, 51), 3, kind)
            self.assertEqual(self.faces_at(cube, 101), 6, kind)

    # saved defaults ------------------------------------------------------

    def test_options_save_clamp_and_reset(self):
        options.save(options.START_FRAME, -5)
        options.save(options.LENGTH, 0)
        self.assertEqual(options.get(options.START_FRAME), -5)
        self.assertEqual(options.get(options.LENGTH), 1)
        options.reset()
        self.assertEqual(options.get(options.START_FRAME), 1)
        self.assertEqual(options.get(options.LENGTH), 100)


if __name__ == "__main__":
    unittest.main()
