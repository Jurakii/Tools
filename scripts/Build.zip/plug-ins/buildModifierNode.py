"""buildModifier node: Blender's Build modifier for Maya meshes.

Outputs the first faces of the incoming mesh, by face number, so the mesh
assembles itself between startFrame and startFrame + length. Vertices that no
face uses are dropped and the rest renumbered; UV sets, colour sets and hard
edges are carried across.

Written against Python API 1.0 because API 2.0 can't add UV or colour sets to
mesh data inside compute().
"""
import os
import sys

import maya.OpenMaya as om
import maya.OpenMayaMPx as ompx

try:
    from build_modifier.formula import visible_face_count
except ImportError:
    # Loaded from plug-ins/ without the module installed: use the sibling scripts folder.
    sys.path.append(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "scripts"))
    from build_modifier.formula import visible_face_count

HAS_NO_EFFECT = 1  # nodeState value shown as "Has No Effect" in the Attribute Editor


class BuildModifierNode(ompx.MPxNode):
    TYPE_NAME = "buildModifier"
    # In-house ID range (0x00000-0x7FFFF). Request a block from Autodesk before sharing outside the studio.
    TYPE_ID = om.MTypeId(0x0007F0B1)

    inMesh = om.MObject()
    time = om.MObject()
    startFrame = om.MObject()
    length = om.MObject()
    outMesh = om.MObject()

    def __init__(self):
        ompx.MPxNode.__init__(self)

    def compute(self, plug, data):
        if plug != BuildModifierNode.outMesh:
            return om.kUnknownParameter

        source_handle = data.inputValue(BuildModifierNode.inMesh)
        out_handle = data.outputValue(BuildModifierNode.outMesh)
        frame = data.inputValue(BuildModifierNode.time).asTime().asUnits(om.MTime.uiUnit())
        start = data.inputValue(BuildModifierNode.startFrame).asDouble()
        length = data.inputValue(BuildModifierNode.length).asDouble()
        has_no_effect = data.inputValue(ompx.cvar.MPxNode_state).asShort() == HAS_NO_EFFECT

        source = source_handle.asMesh()
        if source.isNull():
            out_handle.setMObject(om.MFnMeshData().create())
        else:
            source_fn = om.MFnMesh(source)
            total = source_fn.numPolygons()
            count = total if has_no_effect else visible_face_count(frame, start, length, total)
            if count >= total:
                out_handle.copy(source_handle)
            else:
                out_handle.setMObject(build_partial_mesh(source, count))
        out_handle.setClean()


def build_partial_mesh(source_object, count):
    """New mesh data holding faces 0 to count-1 of `source_object`, without the vertices they don't use."""
    source = om.MFnMesh(source_object)
    all_sizes, all_vertices = om.MIntArray(), om.MIntArray()
    source.getVertices(all_sizes, all_vertices)
    face_sizes = [all_sizes[i] for i in range(count)]
    corner_count = sum(face_sizes)
    new_ids = {}  # old vertex id -> new id, numbered in order of first use
    corners = [new_ids.setdefault(all_vertices[i], len(new_ids)) for i in range(corner_count)]
    old_ids = list(new_ids)

    all_points = om.MFloatPointArray()
    source.getPoints(all_points)
    points = om.MFloatPointArray(len(old_ids))
    for new_id, old_id in enumerate(old_ids):
        points.set(all_points[old_id], new_id)

    mesh_data = om.MFnMeshData().create()
    mesh = om.MFnMesh()
    mesh_object = mesh.create(len(old_ids), count, points, _int_array(face_sizes), _int_array(corners), mesh_data)
    if count:
        _copy_uv_sets(source, mesh, count)
        _copy_color_sets(source, mesh, corner_count)
        _copy_hard_edges(source_object, mesh, mesh_object, old_ids)
    return mesh_data


def _copy_uv_sets(source, mesh, count):
    # New meshes come with one empty set (map1) that can't be renamed on mesh data, so it's
    # filled when the source has a set of that name and every other set is added beside it.
    default_sets = []
    mesh.getUVSetNames(default_sets)
    names = []
    source.getUVSetNames(names)
    for name in names:
        if name not in default_sets:
            mesh.createUVSetDataMeshWithName(name)
        us, vs = om.MFloatArray(), om.MFloatArray()
        source.getUVs(us, vs, name)
        if not us.length():
            continue
        all_counts, all_ids = om.MIntArray(), om.MIntArray()
        source.getAssignedUVs(all_counts, all_ids, name)
        uv_counts = [all_counts[i] for i in range(count)]
        uv_ids = [all_ids[i] for i in range(sum(uv_counts))]
        mesh.setUVs(us, vs, name)
        mesh.assignUVs(_int_array(uv_counts), _int_array(uv_ids), name)
    # The current UV and colour set are stored on the shape, so they carry over without help.


def _copy_color_sets(source, mesh, corner_count):
    names = []
    source.getColorSetNames(names)
    unset = om.MColor(-1.0, -1.0, -1.0, -1.0)
    for name in names:
        rep = source.getColorRepresentation(name)
        mesh.createColorSetDataMesh(name, source.isColorClamped(name), rep)
        colors = om.MColorArray()
        source.getFaceVertexColors(colors, name, unset)
        palette = om.MColorArray()
        ids = []  # one per face-vertex; -1 leaves it without a colour
        for i in range(corner_count):
            color = colors[i]
            if color == unset:
                ids.append(-1)
            else:
                ids.append(palette.length())
                palette.append(color)
        mesh.setColors(palette, name, rep)
        mesh.assignColors(_int_array(ids), name)


def _copy_hard_edges(source_object, mesh, mesh_object, old_ids):
    # New meshes start with every edge soft, so only hard edges need copying.
    hard = set()
    edge = om.MItMeshEdge(source_object)
    while not edge.isDone():
        if not edge.isSmooth():
            a, b = edge.index(0), edge.index(1)
            hard.add((a, b) if a < b else (b, a))
        edge.next()
    if not hard:
        return
    changed = False
    edge = om.MItMeshEdge(mesh_object)
    while not edge.isDone():
        a, b = old_ids[edge.index(0)], old_ids[edge.index(1)]
        if ((a, b) if a < b else (b, a)) in hard:
            mesh.setEdgeSmoothing(edge.index(), False)
            changed = True
        edge.next()
    if changed:
        mesh.cleanupEdgeSmoothing()


def _int_array(values):
    array = om.MIntArray()
    om.MScriptUtil.createIntArrayFromList(values, array)
    return array


def _creator():
    return ompx.asMPxPtr(BuildModifierNode())


def _initialize():
    typed = om.MFnTypedAttribute()
    unit = om.MFnUnitAttribute()
    numeric = om.MFnNumericAttribute()
    node = BuildModifierNode

    node.inMesh = typed.create("inMesh", "im", om.MFnData.kMesh)

    node.time = unit.create("time", "tm", om.MFnUnitAttribute.kTime, 0.0)

    node.startFrame = numeric.create("startFrame", "sf", om.MFnNumericData.kDouble, 1.0)
    numeric.setKeyable(True)

    node.length = numeric.create("length", "len", om.MFnNumericData.kDouble, 100.0)
    numeric.setKeyable(True)
    numeric.setMin(1.0)

    node.outMesh = typed.create("outMesh", "om", om.MFnData.kMesh)
    typed.setWritable(False)
    typed.setStorable(False)

    for attr in (node.inMesh, node.time, node.startFrame, node.length, node.outMesh):
        node.addAttribute(attr)
    for attr in (node.inMesh, node.time, node.startFrame, node.length, ompx.cvar.MPxNode_state):
        node.attributeAffects(attr, node.outMesh)


def initializePlugin(plugin):
    ompx.MFnPlugin(plugin, "build_modifier", "1.0", "Any").registerNode(
        BuildModifierNode.TYPE_NAME, BuildModifierNode.TYPE_ID, _creator, _initialize)


def uninitializePlugin(plugin):
    ompx.MFnPlugin(plugin).deregisterNode(BuildModifierNode.TYPE_ID)
