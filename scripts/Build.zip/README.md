# Build modifier for Maya

Blender's Build modifier for Maya. A mesh assembles itself face by face, in face-number order,
starting at **Start Frame** and finishing **Length** frames later.

Requires Maya 2022 or newer.

## Install

Drag `install_drop.py` into a Maya viewport. It:

- writes `build_modifier.mod` into your Maya modules folder (`Documents/maya/modules`), pointing at this folder, so Maya finds the tool on every start;
- adds a **Build** button to the active shelf.

To install by hand instead, add this folder to `MAYA_MODULE_PATH` in `Maya.env`, then run
`import build_modifier.shelf; build_modifier.shelf.install()` once to add the shelf button.

## Use

| Do this | What happens |
| --- | --- |
| Click **Build** on the shelf | Every selected mesh gets Build, using the saved Start Frame and Length. |
| Double-click **Build** | Opens **Build Options**, where you change the saved Start Frame and Length. |
| Click **Build** on a mesh that already has it | Its Start Frame and Length reset to the saved values. It never adds a second Build. |

After a click, the object shows a **Build** section in the Channel Box with **Start Frame** and **Length**.
They are ordinary keyable channels, and they drive the `buildModifier` node listed under INPUTS.

**Build Options:** fields save as you change them. **Build** applies and closes, **Apply** applies and keeps
the window open, and **Edit › Reset Settings** puts back 1 and 100.

To show the whole mesh without removing Build, set the node's **Node State** to **Has No Effect**.
To take Build off, select the meshes and run:

```python
import build_modifier
build_modifier.remove_build()
```

Everything is in one undo step: one Ctrl+Z removes a Build you just added.

## Good to know

- **Build goes last.** It sits directly above the mesh shape. Deformers already on the mesh (skinning, blend shapes) keep working because they run before Build. Deformers added after Build see the vertex count change every frame and won't work.
- **Face order** is Maya's face numbering, the same rule Blender uses.
- **Carried across:** points, every UV set, every colour set, and hard/soft edges. Not carried: locked custom normals and creases. Normals are recomputed from the hard/soft edges.
- **Renamed first UV set.** If a mesh's first UV set isn't called `map1`, the partly built mesh also has an empty `map1` set. Maya's API can't rename UV sets inside a node.
- **Speed.** The node is Python. In Maya 2024 it takes about 0.02 s per frame for a 10k-face mesh and 0.1 s for 40k faces.
- **Motion blur.** The face count changes between frames, so turn off deformation motion blur on built objects.
- **Sharing scenes.** Scenes with Build need this plug-in installed to open correctly. To hand off a frozen result, go to the frame you want and delete history on the mesh.
- **Double-click.** If Maya runs the click command on the first click of a double-click, the tool undoes that Build before opening the window.
- **Node type ID** `0x7F0B1` is in Autodesk's in-house range. Request your own block from Autodesk before sharing the tool outside your studio.

## Files

```
build_modifier.mod            module file (path relative to this folder)
install_drop.py               drag-and-drop installer
plug-ins/buildModifierNode.py the buildModifier node
scripts/build_modifier/
    __init__.py               apply_build(), show_options(), remove_build()
    formula.py                face-count rule, no Maya imports
    core.py                   adding and removing Build on meshes
    options.py                saved Start Frame and Length (optionVars)
    ui.py                     Build Options window
    shelf.py                  shelf button
icons/buildModifier.png       shelf icon
tests/                        unit and Maya integration tests
```

## Tests

From this folder:

```
"C:/Program Files/Autodesk/Maya2024/bin/mayapy.exe" -m unittest discover -s tests -v
```

The Maya tests start Maya standalone with a throwaway preferences folder, so your own preferences
are untouched. `tests/test_formula.py` also runs under plain Python or pytest.
