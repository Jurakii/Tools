"""Drag this file into a Maya viewport to install Build and add its button to the active shelf.

Writes build_modifier.mod into your Maya modules folder (pointing at this folder), so Maya
finds the scripts, plug-in and icon on every start, and sets up the current session too.
"""
import os
import sys

MODULE_NAME = "build_modifier"
VERSION = "1.0"


def onMayaDroppedPythonFile(*_):
    from maya import cmds

    root = os.path.dirname(os.path.abspath(__file__)).replace("\\", "/")
    modules_dir = os.path.join(cmds.internalVar(userAppDir=True), "modules")
    if not os.path.isdir(modules_dir):
        os.makedirs(modules_dir)
    mod_path = os.path.join(modules_dir, MODULE_NAME + ".mod")
    with open(mod_path, "w") as handle:
        handle.write("+ %s %s %s\n" % (MODULE_NAME, VERSION, root))

    # Maya reads .mod files only at startup, so wire up this session by hand.
    scripts = root + "/scripts"
    if scripts not in sys.path:
        sys.path.append(scripts)
    plugins = root + "/plug-ins"
    plugin_path = os.environ.get("MAYA_PLUG_IN_PATH", "")
    if plugins not in plugin_path.split(os.pathsep):
        os.environ["MAYA_PLUG_IN_PATH"] = plugin_path + os.pathsep + plugins if plugin_path else plugins

    import build_modifier.shelf
    build_modifier.shelf.install()
    cmds.confirmDialog(title="Build installed",
                       message="Build is on your active shelf.\n\nClick it to build the selected meshes.\n"
                               "Double-click it to change Start Frame and Length.\n\nModule file: %s" % mod_path,
                       button=["OK"])
